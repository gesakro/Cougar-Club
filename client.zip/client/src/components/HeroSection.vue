<template>
    <section class="hero">
      <img src="@/assets/img/fondo.jpg" alt="Hero Image" />
      <div class="overlay">
        <h2>Descubre la Nueva Colección</h2>
        <h1>Cougar Club</h1>
        <a href="#" class="shop-button">Comprar Ahora</a>
      </div>
    </section>
  </template>
  
  <script>
  
  
  
  export default {
    name: "HeroSection",
  };
  </script>

<style src="@/assets/styles/hero.css"></style>

  