<template>
  <nav class="navbar">
    <div class="left-section">
      <AppMenu />
      <button class="search-button">Search</button>
    </div>
    <div class="logo">Cougar Club</div>
    <div class="right-section">
      <button class="user-button" @click="goToLogin">
        <img src="@/assets/img/user3.png" alt="User Icon" class="user-icon"/>
      </button>
      <button class="cart-button">🛒</button>
    </div>
  </nav>
</template>

<script>
import AppMenu from "./AppMenu.vue";

export default {
  name: "NavBar",
  components: {
    AppMenu,
  },
  methods: {
    goToLogin() {
    this.$router.push('/login'); // Navega al login
  },
  },
};
</script>

<style src="@/assets/styles/navbar.css"></style>